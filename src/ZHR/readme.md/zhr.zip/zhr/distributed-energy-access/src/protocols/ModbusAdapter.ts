/**
 * Modbus 协议适配器
 * 工业领域最常用的串行通信协议，广泛用于智能电表、RTU等设备
 */

import { BaseProtocolAdapter, ProtocolConfig, ProtocolDataPoint } from './BaseProtocol';

// Modbus 功能码
export enum ModbusFunctionCode {
  READ_COILS = 0x01,
  READ_DISCRETE_INPUTS = 0x02,
  READ_HOLDING_REGISTERS = 0x03,
  READ_INPUT_REGISTERS = 0x04,
  WRITE_SINGLE_COIL = 0x05,
  WRITE_SINGLE_REGISTER = 0x06,
  WRITE_MULTIPLE_REGISTERS = 0x10,
}

export class ModbusAdapter extends BaseProtocolAdapter {
  constructor(config: ProtocolConfig) {
    super(config);
  }

  getProtocolName(): string {
    return 'Modbus';
  }

  async connect(): Promise<boolean> {
    console.log(`[Modbus] Connecting to ${this.config.host}:${this.config.port}, slaveId=${this.config.slaveId || 1}`);
    
    // 实际实现会使用modbus库建立TCP连接
    // 这里是框架实现，模拟连接成功
    await new Promise(resolve => setTimeout(resolve, 50));
    this.status.connected = true;
    this.status.lastConnectTime = Date.now();
    
    console.log(`[Modbus] Connected`);
    return true;
  }

  async disconnect(): Promise<void> {
    console.log(`[Modbus] Disconnecting from ${this.config.host}:${this.config.port}`);
    this.status.connected = false;
    this.status.lastDisconnectTime = Date.now();
    this.dataPoints.clear();
  }

  /**
   * 从 Modbus 读取数据
   * address 格式: "hr:100" 保持寄存器, "ir:100" 输入寄存器, "coil:1" 线圈
   */
  async readDataPoint(address: string): Promise<ProtocolDataPoint | null> {
    if (!this.status.connected) {
      this.recordError('Not connected');
      return null;
    }

    const [type, addrStr] = address.split(':');
    const addr = parseInt(addrStr, 10);
    const now = Date.now();

    // 实际实现会发送Modbus请求并解析响应
    // 这里生成模拟数据
    let value: number = 0;
    let dataType: 'analog' | 'digital' = 'analog';

    if (type === 'hr' || type === 'ir') {
      // 寄存器 - 模拟量
      value = Math.random() * 1000; // 模拟测量值
      dataType = 'analog';
    } else if (type === 'coil' || type === 'di') {
      // 线圈或离散输入 - 开关量
      value = Math.random() > 0.5 ? 1 : 0;
      dataType = 'digital';
    }

    const point: ProtocolDataPoint = {
      id: `modbus_${address}`,
      name: `Modbus_${address}`,
      value,
      type: dataType,
      timestamp: now,
      quality: 'good'
    };

    this.updateDataPoint(point);
    return point;
  }

  async writeDataPoint(address: string, value: number | boolean): Promise<boolean> {
    if (!this.status.connected) {
      this.recordError('Not connected');
      return false;
    }

    const [type, addrStr] = address.split(':');
    const addr = parseInt(addrStr, 10);

    console.log(`[Modbus] Writing ${value} to ${type}:${addr}`);

    // 实际实现：发送Modbus写请求
    const now = Date.now();
    const existing = this.dataPoints.get(`modbus_${address}`);
    const numValue = typeof value === 'boolean' ? (value ? 1 : 0) : value;

    if (existing) {
      existing.value = numValue;
      existing.timestamp = now;
    } else {
      const point: ProtocolDataPoint = {
        id: `modbus_${address}`,
        name: `Modbus_${address}`,
        value: numValue,
        type: type === 'coil' ? 'digital' : 'analog',
        timestamp: now,
        quality: 'good'
      };
      this.updateDataPoint(point);
    }

    return true;
  }

  async readBatch(startAddress: string, count: number): Promise<ProtocolDataPoint[]> {
    const results: ProtocolDataPoint[] = [];
    const [type, startAddrStr] = startAddress.split(':');
    const startAddr = parseInt(startAddrStr, 10);

    for (let i = 0; i < count; i++) {
      const address = `${type}:${startAddr + i}`;
      const point = await this.readDataPoint(address);
      if (point) {
        results.push(point);
      }
    }

    return results;
  }

  /**
   * 计算 Modbus CRC 校验
   */
  calculateCRC(data: Buffer): number {
    let crc = 0xFFFF;
    for (let i = 0; i < data.length; i++) {
      crc ^= data.readUInt8(i);
      for (let j = 0; j < 8; j++) {
        if ((crc & 0x0001) !== 0) {
          crc >>= 1;
          crc ^= 0xA001;
        } else {
          crc >>= 1;
        }
      }
    }
    return crc;
  }

  /**
   * 获取从站ID
   */
  getSlaveId(): number {
    return this.config.slaveId || 1;
  }
}
