/**
 * 电网协议基类
 */

export interface ProtocolDataPoint {
  id: string;
  name: string;
  value: number | boolean | string;
  type: 'analog' | 'digital' | 'string';
  timestamp: number;
  quality: 'good' | 'invalid' | 'old';
}

export interface ProtocolConfig {
  host: string;
  port: number;
  slaveId?: number; // Modbus 从站ID
  endpoint?: string; // OPC UA 端点
  timeout: number;
  pollingInterval: number;
}

export interface ProtocolConnectionStatus {
  connected: boolean;
  lastConnectTime: number;
  lastDisconnectTime: number;
  errorCount: number;
  lastError?: string;
}

export abstract class BaseProtocolAdapter {
  protected config: ProtocolConfig;
  protected status: ProtocolConnectionStatus;
  protected dataPoints: Map<string, ProtocolDataPoint> = new Map();

  constructor(config: ProtocolConfig) {
    this.config = config;
    this.status = {
      connected: false,
      lastConnectTime: 0,
      lastDisconnectTime: 0,
      errorCount: 0
    };
  }

  /**
   * 建立连接
   */
  abstract connect(): Promise<boolean>;

  /**
   * 断开连接
   */
  abstract disconnect(): Promise<void>;

  /**
   * 读取数据点
   */
  abstract readDataPoint(address: string): Promise<ProtocolDataPoint | null>;

  /**
   * 写入数据点
   */
  abstract writeDataPoint(address: string, value: number | boolean): Promise<boolean>;

  /**
   * 批量读取
   */
  abstract readBatch(startAddress: string, count: number): Promise<ProtocolDataPoint[]>;

  /**
   * 获取协议名称
   */
  abstract getProtocolName(): string;

  /**
   * 获取连接状态
   */
  getConnectionStatus(): ProtocolConnectionStatus {
    return { ...this.status };
  }

  /**
   * 获取所有缓存的数据点
   */
  getAllDataPoints(): ProtocolDataPoint[] {
    return Array.from(this.dataPoints.values());
  }

  /**
   * 获取指定数据点
   */
  getDataPoint(id: string): ProtocolDataPoint | undefined {
    return this.dataPoints.get(id);
  }

  /**
   * 更新数据点缓存
   */
  protected updateDataPoint(point: ProtocolDataPoint): void {
    this.dataPoints.set(point.id, point);
  }

  /**
   * 记录错误
   */
  protected recordError(error: string): void {
    this.status.errorCount++;
    this.status.lastError = error;
  }
}
