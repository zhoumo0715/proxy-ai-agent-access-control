/**
 * 电网协议工厂
 * 统一创建和管理各种协议适配器
 */

import { BaseProtocolAdapter, ProtocolConfig } from './BaseProtocol';
import { IEC60870Adapter } from './IEC60870Adapter';
import { ModbusAdapter } from './ModbusAdapter';
import { OPCUAAdapter } from './OPCUAAdapter';

export enum ProtocolType {
  IEC60870_5 = 'iec60870',
  MODBUS = 'modbus',
  OPC_UA = 'opcua',
}

export class ProtocolFactory {
  private static instances: Map<string, BaseProtocolAdapter> = new Map();

  /**
   * 创建协议适配器
   */
  static createAdapter(
    type: ProtocolType,
    config: ProtocolConfig,
    instanceId?: string
  ): BaseProtocolAdapter {
    let adapter: BaseProtocolAdapter;

    switch (type) {
      case ProtocolType.IEC60870_5:
        adapter = new IEC60870Adapter(config);
        break;
      case ProtocolType.MODBUS:
        adapter = new ModbusAdapter(config);
        break;
      case ProtocolType.OPC_UA:
        adapter = new OPCUAAdapter(config);
        break;
      default:
        throw new Error(`Unsupported protocol type: ${type}`);
    }

    const id = instanceId || `${type}_${config.host}_${config.port}`;
    this.instances.set(id, adapter);
    
    return adapter;
  }

  /**
   * 获取已创建的适配器
   */
  static getAdapter(instanceId: string): BaseProtocolAdapter | undefined {
    return this.instances.get(instanceId);
  }

  /**
   * 关闭并移除适配器
   */
  static async removeAdapter(instanceId: string): Promise<void> {
    const adapter = this.instances.get(instanceId);
    if (adapter) {
      await adapter.disconnect();
      this.instances.delete(instanceId);
    }
  }

  /**
   * 获取所有已连接的适配器
   */
  static getAllConnectedAdapters(): BaseProtocolAdapter[] {
    return Array.from(this.instances.values())
      .filter(adapter => adapter.getConnectionStatus().connected);
  }

  /**
   * 关闭所有连接
   */
  static async disconnectAll(): Promise<void> {
    const promises = Array.from(this.instances.values())
      .map(adapter => adapter.disconnect());
    await Promise.all(promises);
    this.instances.clear();
  }

  /**
   * 支持的协议列表
   */
  static getSupportedProtocols(): ProtocolType[] {
    return [
      ProtocolType.IEC60870_5,
      ProtocolType.MODBUS,
      ProtocolType.OPC_UA
    ];
  }
}
