/**
 * 台区代理权限管理 - 台区模型定义
 */

// 台区层级
export enum AreaLevel {
  MAIN = 'main',        // 主站
  PROVINCE = 'province',// 省级
  CITY = 'city',        // 市级
  COUNTY = 'county',    // 县级
  STATION = 'station',  // 台区/站点
}

// 代理权限范围
export interface PermissionScope {
  deviceTypes: string[];       // 允许管控的设备类型
  operations: string[];        // 允许的操作类型
  areaIds: string[];          // 允许管控的台区ID
  maxPower: number;            // 最大允许并网功率(kW)
}

// 代理信息
export interface Agent {
  id: string;                  // 代理ID
  areaId: string;              // 所属台区ID
  parentAgentId?: string;      // 父代理ID
  level: AreaLevel;            // 层级
  permissions: PermissionScope;// 权限范围
  isActive: boolean;           // 是否激活
  createdAt: number;           // 创建时间
  updatedAt: number;           // 更新时间
}

// 台区信息
export interface Area {
  id: string;                  // 台区ID
  name: string;                // 台区名称
  level: AreaLevel;            // 层级
  parentId: string;            // 父台区ID
  agentId: string;             // 当前代理ID
  children: string[];          // 子台区列表
  totalCapacity: number;       // 总装机容量(kW)
  connectedCapacity: number;   // 已并网容量(kW)
  createdAt: number;           // 创建时间
  updatedAt: number;           // 更新时间
  location?: {                // 位置信息
    lat: number;
    lng: number;
  };
}
