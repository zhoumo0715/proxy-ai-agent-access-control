/**
 * 光伏储能终端模型 - 动态接入权限调整
 */

// 设备类型
export enum DeviceType {
  PHOTOVOLTAIC = 'photovoltaic', // 光伏
  ENERGY_STORAGE = 'energy_storage', // 储能
  CHARGING_PILE = 'charging_pile', // 充电桩
  INTEGRATED = 'integrated', // 风光储一体化
}

// 设备状态
export enum DeviceStatus {
  OFFLINE = 'offline',         // 离线
  ONLINE = 'online',           // 在线
  WAITING_APPROVAL = 'waiting_approval', // 待审批
  REJECTED = 'rejected',       // 已拒绝
  DISABLED = 'disabled',       // 已停用
}

// 接入权限
export interface AccessPermission {
  canConnect: boolean;         // 是否允许并网
  maxOutputPower: number;      // 最大输出功率限制
  maxInputPower: number;       // 最大输入功率限制(充电)
  allowedOperations: string[]; // 允许的操作
  priority: number;            // 优先级(用于调峰)
  validUntil?: number;         // 权限有效期
}

// 终端设备信息
export interface EnergyDevice {
  id: string;                  // 设备ID
  name: string;                // 设备名称
  type: DeviceType;            // 设备类型
  areaId: string;              // 所属台区ID
  ownerId: string;             // 所有者ID
  model: string;               // 设备型号
  sn: string;                  // 序列号
  status: DeviceStatus;        // 当前状态
  capacity: number;            // 额定容量/功率
  accessPermission: AccessPermission; // 接入权限
  lastConnectedAt?: number;    // 最后一次连接时间
  lastDisconnectedAt?: number; // 最后一次断开时间
  createdAt: number;
  updatedAt: number;
  metadata?: Record<string, any>;
}

// 动态接入请求
export interface AccessRequest {
  deviceId: string;
  requestedAction: 'connect' | 'disconnect' | 'adjust';
  requestedPermission?: Partial<AccessPermission>;
  requestTime: number;
  requesterId: string;
  reason: string;
}
