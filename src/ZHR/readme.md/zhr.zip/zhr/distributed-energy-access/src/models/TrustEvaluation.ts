/**
 * 新能源并网信任评估模型定义
 */

// 信任等级
export enum TrustLevel {
  EXCELLENT = 'excellent',   // 优秀 - A++
  GOOD = 'good',             // 良好 - A+
  MEDIUM = 'medium',         // 中等 - B
  POOR = 'poor',             // 较差 - C
  UNTRUSTED = 'untrusted',   // 不可信 - D
}

// 评估指标类型
export enum EvaluationMetricType {
  STABILITY = 'stability',         // 运行稳定性
  COMPLIANCE = 'compliance',       // 合规性
  PREDICTION_ACCURACY = 'prediction_accuracy', // 预测准确度
  RESPONSE_SPEED = 'response_speed', // 响应速度
  SAFETY = 'safety',               // 安全记录
  HISTORY = 'history',             // 历史运行
}

// 评估指标
export interface EvaluationMetric {
  type: EvaluationMetricType;
  value: number;             // 指标得分 0-100
  weight: number;            // 权重 0-1
  lastUpdated: number;       // 最后更新时间
  metadata?: Record<string, any>;
}

// 信任评估结果
export interface TrustEvaluationResult {
  deviceId: string;
  overallScore: number;           // 总分 0-100
  trustLevel: TrustLevel;         // 信任等级
  metrics: EvaluationMetric[];    // 各指标详情
  recommendations: TrustRecommendation[]; // 优化建议
  evaluatedAt: number;
}

// 信任调整建议
export interface TrustRecommendation {
  type: 'increase_permission' | 'decrease_permission' | 'maintain' | 'warning';
  description: string;
  suggestedAdjustment?: Partial<{
    maxOutputPower: number;
    priority: number;
  }>;
}

// 评估配置
export interface TrustEvaluationConfig {
  // 各指标默认权重
  defaultWeights: Record<EvaluationMetricType, number>;
  // 是否启用动态权重调整
  enableDynamicWeight: boolean;
  // 评估周期(小时)
  evaluationInterval: number;
  // 是否自动执行调整建议
  autoAdjust: boolean;
  // 分级阈值
  thresholds: {
    [TrustLevel.EXCELLENT]: number;
    [TrustLevel.GOOD]: number;
    [TrustLevel.MEDIUM]: number;
    [TrustLevel.POOR]: number;
  };
}

// 设备运行历史数据
export interface DeviceOperationHistory {
  deviceId: string;
  timestamp: number;
  data: {
    outputPower: number;
    predictedPower: number;
    gridVoltage: number;
    frequency: number;
    isConnected: boolean;
    abnormalEvents: string[];
  };
}
