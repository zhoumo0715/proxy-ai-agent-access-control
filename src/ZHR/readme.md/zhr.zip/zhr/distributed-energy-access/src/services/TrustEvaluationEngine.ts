/**
 * 新能源并网场景信任评估优化引擎
 */
import {
  TrustEvaluationResult,
  TrustEvaluationConfig,
  TrustLevel,
  EvaluationMetric,
  EvaluationMetricType,
  DeviceOperationHistory,
  TrustRecommendation
} from '../models/TrustEvaluation';
import { EnergyDevice, DeviceStatus } from '../models/Device';
import { DynamicAccessManager } from './DynamicAccessManager';
import { AreaAgentManager } from './AreaAgentManager';

export class TrustEvaluationEngine {
  private config: TrustEvaluationConfig;
  private history: Map<string, DeviceOperationHistory[]> = new Map();
  private evaluationResults: Map<string, TrustEvaluationResult> = new Map();
  private dynamicAccessManager: DynamicAccessManager;
  private areaAgentManager: AreaAgentManager;

  constructor(
    areaAgentManager: AreaAgentManager,
    dynamicAccessManager: DynamicAccessManager,
    config?: Partial<TrustEvaluationConfig>
  ) {
    this.areaAgentManager = areaAgentManager;
    this.dynamicAccessManager = dynamicAccessManager;
    this.config = this.getDefaultConfig();
    Object.assign(this.config, config);
  }

  /**
   * 获取默认评估配置
   */
  private getDefaultConfig(): TrustEvaluationConfig {
    return {
      defaultWeights: {
        [EvaluationMetricType.STABILITY]: 0.3,
        [EvaluationMetricType.COMPLIANCE]: 0.25,
        [EvaluationMetricType.PREDICTION_ACCURACY]: 0.2,
        [EvaluationMetricType.RESPONSE_SPEED]: 0.1,
        [EvaluationMetricType.SAFETY]: 0.1,
        [EvaluationMetricType.HISTORY]: 0.05,
      },
      enableDynamicWeight: true,
      evaluationInterval: 24, // 默认24小时评估一次
      autoAdjust: true,
      thresholds: {
        [TrustLevel.EXCELLENT]: 90,
        [TrustLevel.GOOD]: 75,
        [TrustLevel.MEDIUM]: 60,
        [TrustLevel.POOR]: 40,
        // <40 就是 UNTRUSTED
      }
    };
  }

  /**
   * 添加设备运行历史数据
   */
  addOperationHistory(record: DeviceOperationHistory): void {
    if (!this.history.has(record.deviceId)) {
      this.history.set(record.deviceId, []);
    }
    this.history.get(record.deviceId)!.push(record);
    
    // 按时间排序
    this.history.get(record.deviceId)!.sort((a, b) => a.timestamp - b.timestamp);
  }

  /**
   * 对设备执行信任评估
   */
  evaluateDevice(deviceId: string): TrustEvaluationResult {
    const device = this.dynamicAccessManager.getDevice(deviceId);
    if (!device) {
      throw new Error(`设备 ${deviceId} 不存在`);
    }

    const metrics: EvaluationMetric[] = [];
    const history = this.history.get(deviceId) || [];
    const now = Date.now();

    // 计算各项指标得分
    metrics.push(this.evaluateStability(deviceId, history));
    metrics.push(this.evaluatePredictionAccuracy(deviceId, history));
    metrics.push(this.evaluateSafety(deviceId, history));
    metrics.push(this.evaluateCompliance(device));
    
    if (history.length > 0) {
      metrics.push(this.evaluateHistory(device, history));
    }

    // 动态权重调整
    if (this.config.enableDynamicWeight) {
      this.adjustWeights(metrics);
    } else {
      // 使用默认权重
      for (const metric of metrics) {
        metric.weight = this.config.defaultWeights[metric.type];
      }
    }

    // 计算总分
    const overallScore = Math.round(
      metrics.reduce((sum, m) => sum + m.value * m.weight, 0) * 100
    ) / 100;

    // 确定信任等级
    const trustLevel = this.getTrustLevel(overallScore);

    // 生成优化建议
    const recommendations = this.generateRecommendations(
      overallScore,
      trustLevel,
      metrics,
      device
    );

    const result: TrustEvaluationResult = {
      deviceId,
      overallScore,
      trustLevel,
      metrics,
      recommendations,
      evaluatedAt: now,
    };

    this.evaluationResults.set(deviceId, result);

    // 如果启用自动调整，根据评估结果调整权限
    if (this.config.autoAdjust && recommendations.length > 0) {
      this.autoAdjustPermissions(deviceId, result);
    }

    return result;
  }

  /**
   * 运行稳定性评估 - 基于异常次数计算
   */
  private evaluateStability(deviceId: string, history: DeviceOperationHistory[]): EvaluationMetric {
    let abnormalCount = 0;
    const totalCount = history.length;
    
    for (const record of history) {
      if (record.data.abnormalEvents.length > 0) {
        abnormalCount++;
      }
    }

    const value = totalCount > 0 
      ? Math.max(0, 100 - (abnormalCount / totalCount) * 100)
      : 50; // 没有历史数据给中等分

    return {
      type: EvaluationMetricType.STABILITY,
      value,
      weight: this.config.defaultWeights[EvaluationMetricType.STABILITY],
      lastUpdated: Date.now(),
      metadata: { abnormalCount, totalCount }
    };
  }

  /**
   * 预测准确度评估 - 对比预测值和实际出力
   */
  private evaluatePredictionAccuracy(deviceId: string, history: DeviceOperationHistory[]): EvaluationMetric {
    if (history.length === 0) {
      return {
        type: EvaluationMetricType.PREDICTION_ACCURACY,
        value: 50,
        weight: this.config.defaultWeights[EvaluationMetricType.PREDICTION_ACCURACY],
        lastUpdated: Date.now(),
      };
    }

    let totalError = 0;
    let count = 0;

    for (const record of history) {
      if (record.data.predictedPower > 0) {
        const error = Math.abs(
          (record.data.outputPower - record.data.predictedPower) / record.data.predictedPower
        );
        totalError += error;
        count++;
      }
    }

    const avgError = count > 0 ? totalError / count : 0.5;
    const value = Math.max(0, 100 - avgError * 100);

    return {
      type: EvaluationMetricType.PREDICTION_ACCURACY,
      value,
      weight: this.config.defaultWeights[EvaluationMetricType.PREDICTION_ACCURACY],
      lastUpdated: Date.now(),
      metadata: { avgError, samples: count }
    };
  }

  /**
   * 安全性评估
   */
  private evaluateSafety(deviceId: string, history: DeviceOperationHistory[]): EvaluationMetric {
    let safetyIncidents = 0;
    
    for (const record of history) {
      const hasSafetyIssue = record.data.abnormalEvents.some(
        e => e.includes('overvoltage') || e.includes('overcurrent') || e.includes('island')
      );
      if (hasSafetyIssue) {
        safetyIncidents++;
      }
    }

    const value = history.length === 0 
      ? 70 // 新设备给默认良好分
      : Math.max(0, 100 - safetyIncidents * 20);

    return {
      type: EvaluationMetricType.SAFETY,
      value,
      weight: this.config.defaultWeights[EvaluationMetricType.SAFETY],
      lastUpdated: Date.now(),
      metadata: { safetyIncidents }
    };
  }

  /**
   * 合规性评估 - 检查是否在权限范围内运行
   */
  private evaluateCompliance(device: EnergyDevice): EvaluationMetric {
    // 可以基于实际运行数据与权限限制对比
    // 这里简化处理，返回基于设备状态的基础分
    const value = device.status === 'online' && device.accessPermission.canConnect ? 80 : 50;

    return {
      type: EvaluationMetricType.COMPLIANCE,
      value,
      weight: this.config.defaultWeights[EvaluationMetricType.COMPLIANCE],
      lastUpdated: Date.now(),
    };
  }

  /**
   * 历史信任累积评估
   */
  private evaluateHistory(device: EnergyDevice, history: DeviceOperationHistory[]): EvaluationMetric {
    const daysOnline = device.lastConnectedAt 
      ? Math.round((Date.now() - device.createdAt) / (1000 * 60 * 60 * 24))
      : 0;
    
    // 越老越稳定，加分上限到90
    const value = Math.min(90, 50 + daysOnline * 0.5);

    return {
      type: EvaluationMetricType.HISTORY,
      value,
      weight: this.config.defaultWeights[EvaluationMetricType.HISTORY],
      lastUpdated: Date.now(),
      metadata: { daysOnline }
    };
  }

  /**
   * 动态权重调整 - 对低分指标增加权重
   */
  private adjustWeights(metrics: EvaluationMetric[]): void {
    let totalLowScore = 0;
    
    for (const metric of metrics) {
      if (metric.value < 60) {
        totalLowScore += (60 - metric.value);
      }
    }

    if (totalLowScore > 0) {
      let totalWeight = 0;
      for (const metric of metrics) {
        let adjustment = metric.value < 60 ? (60 - metric.value) / totalLowScore * 0.2 : 0;
        const baseWeight = this.config.defaultWeights[metric.type];
        metric.weight = Math.max(0.05, baseWeight + adjustment);
        totalWeight += metric.weight;
      }

      // 归一化权重总和为1
      for (const metric of metrics) {
        metric.weight /= totalWeight;
      }
    }
  }

  /**
   * 根据总分获得信任等级
   */
  private getTrustLevel(score: number): TrustLevel {
    if (score >= this.config.thresholds[TrustLevel.EXCELLENT]) {
      return TrustLevel.EXCELLENT;
    } else if (score >= this.config.thresholds[TrustLevel.GOOD]) {
      return TrustLevel.GOOD;
    } else if (score >= this.config.thresholds[TrustLevel.MEDIUM]) {
      return TrustLevel.MEDIUM;
    } else if (score >= this.config.thresholds[TrustLevel.POOR]) {
      return TrustLevel.POOR;
    } else {
      return TrustLevel.UNTRUSTED;
    }
  }

  /**
   * 生成调整建议
   */
  private generateRecommendations(
    score: number,
    level: TrustLevel,
    metrics: EvaluationMetric[],
    device: EnergyDevice
  ): TrustRecommendation[] {
    const recommendations: TrustRecommendation[] = [];

    if (level === TrustLevel.EXCELLENT && score > 95) {
      recommendations.push({
        type: 'increase_permission',
        description: '信任等级优秀，可以放宽出力限制提高优先级',
        suggestedAdjustment: {
          maxOutputPower: device.capacity,
          priority: 1,
        }
      });
    } else if (level === TrustLevel.POOR) {
      recommendations.push({
        type: 'decrease_permission',
        description: `信任等级较差，多个指标(${
          metrics.filter(m => m.value < 50).map(m => m.type).join(',')
        })得分偏低，建议降低出力限制`,
        suggestedAdjustment: {
          maxOutputPower: device.capacity * 0.4,
          priority: 10,
        }
      });
    } else if (level === TrustLevel.UNTRUSTED) {
      recommendations.push({
        type: 'decrease_permission',
        description: '信任等级不合格，建议暂停并网',
        suggestedAdjustment: {
          maxOutputPower: 0,
        }
      });
    } else {
      recommendations.push({
        type: 'maintain',
        description: '信任等级稳定，保持当前权限',
      });
    }

    return recommendations;
  }

  /**
   * 自动调整设备接入权限
   */
  private autoAdjustPermissions(deviceId: string, result: TrustEvaluationResult): void {
    const device = this.dynamicAccessManager.getDevice(deviceId);
    if (!device) return;

    const topRecommendation = result.recommendations[0];
    if (topRecommendation.suggestedAdjustment) {
      const area = this.areaAgentManager.getArea(device.areaId);
      
      const maxCapacity = area 
        ? Math.min(device.capacity, area.totalCapacity) 
        : device.capacity;
      
      this.dynamicAccessManager.adjustPermissionByTrustScore(
        deviceId,
        result.overallScore,
        Math.min(maxCapacity, topRecommendation.suggestedAdjustment.maxOutputPower || device.capacity)
      );
    }
  }

  /**
   * 获取最新评估结果
   */
  getLatestEvaluation(deviceId: string): TrustEvaluationResult | undefined {
    return this.evaluationResults.get(deviceId);
  }

  /**
   * 批量评估所有在线设备
   */
  evaluateAllOnlineDevices(): TrustEvaluationResult[] {
    const onlineDevices = this.dynamicAccessManager.listDevicesByStatus(DeviceStatus.ONLINE);
    return onlineDevices
      .map(d => {
        try {
          return this.evaluateDevice(d.id);
        } catch (e) {
          console.error(`评估设备 ${d.id} 出错:`, e);
          return null;
        }
      })
      .filter(r => r !== null) as TrustEvaluationResult[];
  }

  /**
   * 更新评估配置
   */
  updateConfig(newConfig: Partial<TrustEvaluationConfig>): void {
    Object.assign(this.config, newConfig);
  }

  getConfig(): TrustEvaluationConfig {
    return { ...this.config };
  }
}
