/**
 * 光伏储能终端动态接入权限调整服务
 */
import { EnergyDevice, DeviceType, DeviceStatus, AccessPermission, AccessRequest } from '../models/Device';
import { AreaAgentManager } from './AreaAgentManager';

export class DynamicAccessManager {
  private devices: Map<string, EnergyDevice> = new Map();
  private accessRequests: Map<string, AccessRequest> = new Map();
  private areaAgentManager: AreaAgentManager;

  constructor(areaAgentManager: AreaAgentManager) {
    this.areaAgentManager = areaAgentManager;
  }

  /**
   * 注册新设备
   */
  registerDevice(
    deviceInfo: Omit<EnergyDevice, 'status' | 'accessPermission' | 'createdAt' | 'updatedAt'>,
    agentId: string
  ): { success: boolean; device?: EnergyDevice; message: string } {
    // 校验代理权限
    if (!this.areaAgentManager.checkPermission(
      agentId,
      deviceInfo.areaId,
      deviceInfo.type,
      'register'
    )) {
      return {
        success: false,
        message: '代理无此台区设备注册权限'
      };
    }

    // 检查台区容量是否充足
    const area = this.areaAgentManager.getArea(deviceInfo.areaId);
    if (area) {
      const availableCapacity = area.totalCapacity - area.connectedCapacity;
      if (availableCapacity < deviceInfo.capacity) {
        return {
          success: false,
          message: '台区可用容量不足，无法接入'
        };
      }
    }

    const now = Date.now();
    // 默认权限配置
    const defaultPermission: AccessPermission = {
      canConnect: false, // 初始待审批，不能直接并网
      maxOutputPower: 0,
      maxInputPower: 0,
      allowedOperations: ['query_status'],
      priority: 5,
    };

    const newDevice: EnergyDevice = {
      ...deviceInfo,
      status: DeviceStatus.WAITING_APPROVAL,
      accessPermission: defaultPermission,
      createdAt: now,
      updatedAt: now,
    };

    this.devices.set(newDevice.id, newDevice);
    
    return {
      success: true,
      device: newDevice,
      message: '设备注册成功，等待并网审批'
    };
  }

  /**
   * 处理接入请求
   */
  processAccessRequest(
    request: AccessRequest,
    agentId: string
  ): { success: boolean; device?: EnergyDevice; message: string } {
    const device = this.devices.get(request.deviceId);
    if (!device) {
      return { success: false, message: '设备不存在' };
    }

    // 校验权限
    if (!this.areaAgentManager.checkPermission(
      agentId,
      device.areaId,
      device.type,
      request.requestedAction
    )) {
      return { success: false, message: '无权限处理此请求' };
    }

    this.accessRequests.set(`${request.deviceId}_${request.requestTime}`, request);
    const now = Date.now();

    switch (request.requestedAction) {
      case 'connect': {
        if (request.requestedPermission) {
          device.accessPermission = {
            ...device.accessPermission,
            ...request.requestedPermission,
          };
        } else {
          device.accessPermission.canConnect = true;
          device.accessPermission.maxOutputPower = device.capacity;
          if (device.type === DeviceType.ENERGY_STORAGE) {
            device.accessPermission.maxInputPower = device.capacity;
          }
        }
        device.status = DeviceStatus.ONLINE;
        device.lastConnectedAt = now;

        // 更新台区已接入容量
        const area = this.areaAgentManager.getArea(device.areaId);
        if (area) {
          area.connectedCapacity += device.capacity;
          area.updatedAt = now;
        }
        break;
      }

      case 'disconnect': {
        device.accessPermission.canConnect = false;
        device.status = DeviceStatus.OFFLINE;
        device.lastDisconnectedAt = now;

        // 释放台区容量
        const area = this.areaAgentManager.getArea(device.areaId);
        if (area) {
          area.connectedCapacity -= device.capacity;
          area.updatedAt = now;
        }
        break;
      }

      case 'adjust': {
        if (request.requestedPermission) {
          device.accessPermission = {
            ...device.accessPermission,
            ...request.requestedPermission,
          };
        }
        break;
      }
    }

    device.updatedAt = now;
    return {
      success: true,
      device,
      message: `已${request.requestedAction}设备: ${device.name}`
    };
  }

  /**
   * 根据信任评估结果动态调整权限
   */
  adjustPermissionByTrustScore(
    deviceId: string,
    trustScore: number,
    maxCapacity: number
  ): AccessPermission {
    const device = this.devices.get(deviceId);
    if (!device) throw new Error('设备不存在');

    const oldPermission = device.accessPermission;
    let newMaxOutput = oldPermission.maxOutputPower;

    // 根据信任分动态调整允许出力
    if (trustScore >= 90) {
      newMaxOutput = Math.min(maxCapacity, device.capacity);
    } else if (trustScore >= 70) {
      newMaxOutput = Math.min(maxCapacity, device.capacity * 0.9);
    } else if (trustScore >= 50) {
      newMaxOutput = Math.min(maxCapacity, device.capacity * 0.7);
    } else if (trustScore >= 30) {
      newMaxOutput = Math.min(maxCapacity, device.capacity * 0.4);
    } else {
      newMaxOutput = 0;
      device.accessPermission.canConnect = false;
      device.status = DeviceStatus.DISABLED;
    }

    device.accessPermission.maxOutputPower = newMaxOutput;
    device.updatedAt = Date.now();

    return device.accessPermission;
  }

  /**
   * 离线设备检测与处理
   */
  handleOfflineDevices(timeoutMs: number = 3600000): string[] {
    const now = Date.now();
    const offlineDevices: string[] = [];

    for (const device of this.devices.values()) {
      if (device.status === DeviceStatus.ONLINE && device.lastConnectedAt) {
        if (now - device.lastConnectedAt > timeoutMs) {
          device.status = DeviceStatus.OFFLINE;
          device.lastDisconnectedAt = now;
          device.updatedAt = now;
          offlineDevices.push(device.id);
        }
      }
    }

    return offlineDevices;
  }

  /**
   * 获取设备接入信息
   */
  getDevice(deviceId: string): EnergyDevice | undefined {
    return this.devices.get(deviceId);
  }

  /**
   * 列出台区所有设备
   */
  listDevicesByArea(areaId: string): EnergyDevice[] {
    return Array.from(this.devices.values())
      .filter(device => device.areaId === areaId);
  }

  /**
   * 按状态过滤设备
   */
  listDevicesByStatus(status: DeviceStatus): EnergyDevice[] {
    return Array.from(this.devices.values())
      .filter(device => device.status === status);
  }

  /**
   * 获取总在线容量
   */
  getTotalOnlineCapacityByArea(areaId: string): number {
    const devices = this.listDevicesByArea(areaId);
    return devices
      .filter(d => d.status === DeviceStatus.ONLINE && d.accessPermission.canConnect)
      .reduce((sum, d) => sum + d.accessPermission.maxOutputPower, 0);
  }
}
