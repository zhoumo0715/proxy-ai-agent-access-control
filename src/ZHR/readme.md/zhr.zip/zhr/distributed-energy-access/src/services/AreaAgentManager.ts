/**
 * 台区代理权限管理服务
 */
import { Area, Agent, AreaLevel, PermissionScope } from '../models/Area';

export class AreaAgentManager {
  private areas: Map<string, Area> = new Map();
  private agents: Map<string, Agent> = new Map();

  /**
   * 创建台区
   */
  createArea(area: Omit<Area, 'children' | 'createdAt' | 'updatedAt'>): Area {
    const now = Date.now();
    const newArea: Area = {
      ...area,
      children: [],
      createdAt: now,
      updatedAt: now,
    };
    this.areas.set(newArea.id, newArea);
    
    // 如果有父台区，添加到父台区的子列表中
    if (newArea.parentId && this.areas.has(newArea.parentId)) {
      const parent = this.areas.get(newArea.parentId)!;
      parent.children.push(newArea.id);
      parent.updatedAt = now;
    }
    
    return newArea;
  }

  /**
   * 创建代理并分配台区
   */
  createAgent(agentInfo: Omit<Agent, 'createdAt' | 'updatedAt'>): Agent {
    const now = Date.now();
    const agent: Agent = {
      ...agentInfo,
      createdAt: now,
      updatedAt: now,
    };
    
    this.agents.set(agent.id, agent);
    
    // 更新台区的代理ID
    if (this.areas.has(agent.areaId)) {
      const area = this.areas.get(agent.areaId)!;
      area.agentId = agent.id;
      area.updatedAt = now;
    }
    
    return agent;
  }

  /**
   * 校验代理是否有权限管控指定设备
   */
  checkPermission(
    agentId: string,
    areaId: string,
    deviceType: string,
    operation: string
  ): boolean {
    const agent = this.agents.get(agentId);
    if (!agent || !agent.isActive) return false;

    // 检查台区范围
    if (!agent.permissions.areaIds.includes(areaId) && agent.areaId !== areaId) {
      // 递归检查是否是子台区
      if (!this.isDescendantArea(agent.areaId, areaId)) {
        return false;
      }
    }

    // 检查设备类型
    if (!agent.permissions.deviceTypes.includes(deviceType) && 
        agent.permissions.deviceTypes.length > 0) {
      return false;
    }

    // 检查操作类型
    if (!agent.permissions.operations.includes(operation) &&
        agent.permissions.operations.length > 0) {
      return false;
    }

    return true;
  }

  /**
   * 检查目标台区是否是源台区的后代
   */
  private isDescendantArea(sourceAreaId: string, targetAreaId: string): boolean {
    const source = this.areas.get(sourceAreaId);
    if (!source) return false;
    
    if (source.children.includes(targetAreaId)) return true;
    
    for (const childId of source.children) {
      if (this.isDescendantArea(childId, targetAreaId)) {
        return true;
      }
    }
    
    return false;
  }

  /**
   * 更新代理权限范围
   */
  updateAgentPermissions(agentId: string, newPermissions: Partial<PermissionScope>): Agent | null {
    const agent = this.agents.get(agentId);
    if (!agent) return null;
    
    agent.permissions = {
      ...agent.permissions,
      ...newPermissions,
    };
    agent.updatedAt = Date.now();
    
    return agent;
  }

  /**
   * 停用代理
   */
  deactivateAgent(agentId: string): boolean {
    const agent = this.agents.get(agentId);
    if (!agent) return false;
    
    agent.isActive = false;
    agent.updatedAt = Date.now();
    return true;
  }

  /**
   * 获取台区下所有代理链(用于权限溯源审计)
   */
  getAgentChain(areaId: string): Agent[] {
    const chain: Agent[] = [];
    let currentArea = this.areas.get(areaId);
    
    while (currentArea) {
      if (currentArea.agentId && this.agents.has(currentArea.agentId)) {
        chain.push(this.agents.get(currentArea.agentId)!);
      }
      if (currentArea.parentId && this.areas.has(currentArea.parentId)) {
        currentArea = this.areas.get(currentArea.parentId);
      } else {
        break;
      }
    }
    
    return chain;
  }

  // 查询方法
  getArea(areaId: string): Area | undefined {
    return this.areas.get(areaId);
  }

  getAgent(agentId: string): Agent | undefined {
    return this.agents.get(agentId);
  }

  listAreasByParent(parentId: string): Area[] {
    return Array.from(this.areas.values())
      .filter(area => area.parentId === parentId);
  }

  getTotalConnectedCapacity(areaId: string): number {
    const area = this.areas.get(areaId);
    return area?.connectedCapacity || 0;
  }
}
