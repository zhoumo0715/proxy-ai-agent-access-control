/**
 * 分布式新能源接入管控系统 - 使用示例
 */

import { AreaAgentManager } from '../src/services/AreaAgentManager';
import { DynamicAccessManager } from '../src/services/DynamicAccessManager';
import { TrustEvaluationEngine } from '../src/services/TrustEvaluationEngine';
import { AreaLevel } from '../src/models/Area';
import { DeviceType } from '../src/models/Device';

console.log('=== 分布式新能源接入管控系统示例 ===');

// 1. 初始化各模块
const areaAgentManager = new AreaAgentManager();
const dynamicAccessManager = new DynamicAccessManager(areaAgentManager);
const trustEvaluationEngine = new TrustEvaluationEngine(
  areaAgentManager,
  dynamicAccessManager,
  { autoAdjust: true }
);

// 2. 创建台区层级
console.log('\n1. 创建台区结构:');
const cityArea = areaAgentManager.createArea({
  id: 'city-001',
  name: 'XX市',
  level: AreaLevel.CITY,
  parentId: '',
  agentId: '',
  totalCapacity: 10000, // 总容量10MW
  connectedCapacity: 0,
});
console.log(`  创建市级台区: ${cityArea.name} (${cityArea.id})`);

const stationArea = areaAgentManager.createArea({
  id: 'station-001',
  name: 'XX街道台区',
  level: AreaLevel.STATION,
  parentId: cityArea.id,
  agentId: '',
  totalCapacity: 1000, // 总容量1MW
  connectedCapacity: 0,
});
console.log(`  创建街道台区: ${stationArea.name} (${stationArea.id})`);

// 3. 创建台区代理
console.log('\n2. 创建台区代理:');
const agent = areaAgentManager.createAgent({
  id: 'agent-001',
  areaId: stationArea.id,
  level: AreaLevel.STATION,
  isActive: true,
  permissions: {
    deviceTypes: ['photovoltaic', 'energy_storage'],
    operations: ['register', 'connect', 'disconnect', 'adjust'],
    areaIds: [stationArea.id],
    maxPower: 1000,
  },
});
console.log(`  创建代理: ID ${agent.id}, 负责台区 ${agent.areaId}`);

// 验证权限
const hasPermission = areaAgentManager.checkPermission(
  agent.id,
  stationArea.id,
  'photovoltaic',
  'register'
);
console.log(`  检查权限: 注册光伏设备 -> ${hasPermission ? '✓ 通过' : '✗ 拒绝'}`);

// 4. 注册光伏设备
console.log('\n3. 设备注册:');
const pvResult = dynamicAccessManager.registerDevice({
  id: 'pv-001',
  name: '居民屋顶光伏-1',
  type: DeviceType.PHOTOVOLTAIC,
  areaId: stationArea.id,
  ownerId: 'user-001',
  model: 'SMA-5KW',
  sn: 'SN12345678',
  capacity: 5, // 5kW
}, agent.id);
console.log(`  注册光伏设备: ${pvResult.success ? '✓ 成功' : '✗ 失败'} - ${pvResult.message}`);

// 注册储能设备
const esResult = dynamicAccessManager.registerDevice({
  id: 'es-001',
  name: '用户侧储能-1',
  type: DeviceType.ENERGY_STORAGE,
  areaId: stationArea.id,
  ownerId: 'user-001',
  model: 'BYD-10KWh',
  sn: 'SN87654321',
  capacity: 10, // 10kW
}, agent.id);
console.log(`  注册储能设备: ${esResult.success ? '✓ 成功' : '✗ 失败'} - ${esResult.message}`);

// 5. 批准并网接入
console.log('\n4. 批准并网接入:');
const pvConnectResult = dynamicAccessManager.processAccessRequest({
  deviceId: 'pv-001',
  requestedAction: 'connect',
  requestTime: Date.now(),
  requesterId: agent.id,
  reason: '验收合格，允许并网',
}, agent.id);
console.log(`  光伏并网: ${pvConnectResult.success ? '✓ 成功' : '✗ 失败'} - ${pvConnectResult.message}`);

const esConnectResult = dynamicAccessManager.processAccessRequest({
  deviceId: 'es-001',
  requestedAction: 'connect',
  requestTime: Date.now(),
  requesterId: agent.id,
  reason: '验收合格，允许并网',
}, agent.id);
console.log(`  储能并网: ${esConnectResult.success ? '✓ 成功' : '✗ 失败'} - ${esConnectResult.message}`);

console.log(`  台区已接入容量: ${stationArea.connectedCapacity} kW / ${stationArea.totalCapacity} kW`);

// 6. 添加运行历史数据并做信任评估
console.log('\n5. 信任评估:');

// 添加光伏三天运行数据
const now = Date.now();
for (let i = 0; i < 72; i++) {
  trustEvaluationEngine.addOperationHistory({
    deviceId: 'pv-001',
    timestamp: now - (72 - i) * 3600 * 1000,
    data: {
      outputPower: 4 + Math.random() * 1,
      predictedPower: 4.2,
      gridVoltage: 220 + (Math.random() * 4 - 2),
      frequency: 50 + (Math.random() * 0.1 - 0.05),
      isConnected: true,
      abnormalEvents: i % 20 === 0 ? ['minor_prediction_error'] : [],
    },
  });
}

// 添加储能运行数据
for (let i = 0; i < 72; i++) {
  trustEvaluationEngine.addOperationHistory({
    deviceId: 'es-001',
    timestamp: now - (72 - i) * 3600 * 1000,
    data: {
      outputPower: i % 2 === 0 ? 8 : 0,
      predictedPower: i % 2 === 0 ? 8 : 0,
      gridVoltage: 220 + (Math.random() * 2 - 1),
      frequency: 50 + (Math.random() * 0.08 - 0.04),
      isConnected: true,
      abnormalEvents: [], // 异常记录很少，表现优秀
    },
  });
}

// 执行评估
const pvEvaluation = trustEvaluationEngine.evaluateDevice('pv-001');
console.log(`  光伏设备评估结果: 得分 ${pvEvaluation.overallScore}, 等级 ${pvEvaluation.trustLevel}`);
console.log(`  建议: ${pvEvaluation.recommendations[0].description}`);

const esEvaluation = trustEvaluationEngine.evaluateDevice('es-001');
console.log(`  储能设备评估结果: 得分 ${esEvaluation.overallScore}, 等级 ${esEvaluation.trustLevel}`);
console.log(`  建议: ${esEvaluation.recommendations[0].description}`);

// 7. 查看调整后的权限
console.log('\n6. 动态调整后设备权限:');
const pvDevice = dynamicAccessManager.getDevice('pv-001');
console.log(`  光伏设备当前最大出力限制: ${pvDevice?.accessPermission.maxOutputPower} kW / ${pvDevice?.capacity} kW`);

const esDevice = dynamicAccessManager.getDevice('es-001');
console.log(`  储能设备当前最大出力限制: ${esDevice?.accessPermission.maxOutputPower} kW / ${esDevice?.capacity} kW`);

// 8. 列出台区当前所有设备
console.log('\n7. 台区设备列表:');
const devices = dynamicAccessManager.listDevicesByArea(stationArea.id);
devices.forEach(d => {
  console.log(`  - ${d.name} [${d.type}]: 状态=${d.status}, 允许并网=${d.accessPermission.canConnect}`);
});

console.log('\n=== 示例执行完成 ===');
