from typing import List, Tuple, Optional
import time

from src.alignment.schema_manager import (
    SecuritySchema,
    SchemaManager,
    GridProtocolSupport
)
from src.alignment.embedding_matcher import (
    EmbeddingMatcher,
    DistributedEnergyTrustOptimizer,
    DistrictHierarchyManager,
    VPPBoundaryManager
)
from src.models.access_request import (
    AccessRequest,
    AccessAction,
    DecisionOutcome,
    MatchingResult,
    ValidationResult
)


class AlignmentValidator:
    """
    对齐验证器 - 主验证入口
    集成动态信念图(DBG) + 安全基模对比(SSC)
    性能要求：单请求延迟 < 8ms
    规模要求：支持10000+节点
    """
    
    def __init__(
        self,
        schema_manager: SchemaManager,
        embedding_matcher: EmbeddingMatcher,
        min_alignment_threshold: float = 0.8,
        challenge_threshold: float = 0.5,
        limit_threshold: float = 0.2,
    ):
        self.schema_manager = schema_manager
        self.embedding_matcher = embedding_matcher
        
        # 分级阈值
        self.min_alignment_threshold = min_alignment_threshold  # 允许阈值
        self.challenge_threshold = challenge_threshold          # 挑战阈值
        self.limit_threshold = limit_threshold                  # 限制阈值
        # < 0.0 隔离
        
        # 开发2 - 电网场景扩展模块初始化
        self.distributed_energy_trust_optimizer = DistributedEnergyTrustOptimizer()
        self.district_hierarchy_manager = DistrictHierarchyManager()
        self.vpp_boundary_manager = VPPBoundaryManager()
        self.grid_protocol_support = GridProtocolSupport()
    
    def validate_llm_decision(
        self,
        request: AccessRequest,
        llm_decision: DecisionOutcome,
        llm_reasoning: str
    ) -> ValidationResult:
        """
        验证LLM决策是否与安全基模对齐
        主入口，性能优化：计时确保<8ms
        """
        start_time = time.perf_counter()
        
        # 获取候选基模 - 使用域索引加速
        domain = request.context.get('domain', 'general')
        if domain:
            candidate_schemas = self.schema_manager.get_schemas_by_domain(domain)
            # 如果是新能源场景，加上终端类型索引
            terminal_type = request.context.get('terminal_type')
            if terminal_type:
                terminal_schemas = self.schema_manager.get_schemas_by_terminal(terminal_type)
                # 合并去重
                schema_ids = set()
                combined = []
                for s in candidate_schemas + terminal_schemas:
                    if s.id not in schema_ids:
                        schema_ids.add(s.id)
                        combined.append(s)
                candidate_schemas = combined
        else:
            candidate_schemas = self.schema_manager.list_schemas()
        
        # 如果没有候选基模，使用全部
        if not candidate_schemas:
            candidate_schemas = self.schema_manager.list_schemas()
        
        # 匹配
        requester = request.requester_id
        target = request.target_id
        action = request.action
        trust = request.context.get('trust', 0.5)
        
        # 检查配电网分层权限（开发2功能）
        if domain == 'district' and request.context.get('hierarchical_check', True):
            hierarchy_allowed = self.district_hierarchy_manager.is_access_allowed(
                requester, target
            )
            if not hierarchy_allowed:
                # 分层权限禁止，直接拒绝
                end_time = time.perf_counter()
                # print(f"Validation took {(end_time - start_time)*1000:.2f}ms")
                return ValidationResult(
                    valid=False,
                    alignment_score=0.0,
                    best_match_schema=None,
                    matching_results=[],
                    recommendation=DecisionOutcome.DENY,
                    reason="配电网分层权限隔离禁止：不允许下级代理访问上级资源",
                    request=request
                )
        
        # 检查VPP边界（开发2功能）
        vpp_id = request.context.get('vpp_id')
        if vpp_id and domain == 'vpp':
            in_boundary = self.vpp_boundary_manager.check_cross_agent_access(
                requester, target, vpp_id
            )
            if not in_boundary:
                end_time = time.perf_counter()
                return ValidationResult(
                    valid=False,
                    alignment_score=0.0,
                    best_match_schema=None,
                    matching_results=[],
                    recommendation=DecisionOutcome.DENY,
                    reason="虚拟电厂信任边界检查失败：访问者或目标不在信任边界内",
                    request=request
                )
        
        # 分布式新能源信任优化（开发2功能）
        terminal_id = request.context.get('terminal_id')
        if terminal_id and domain == 'distributed_new_energy':
            # 更新信任度
            trust = self.distributed_energy_trust_optimizer.get_current_trust(terminal_id)
            request.context['trust'] = trust
        
        matching_results = []
        matches = self.embedding_matcher.match_schema(
            requester, target, action.value, candidate_schemas
        )
        
        best_score = 0.0
        best_match = None
        
        for schema, s_match, o_match, a_match, emb_sim in matches:
            overall = self.embedding_matcher.compute_overall_score(
                s_match, o_match, a_match, emb_sim, schema, trust
            )
            
            matching_results.append(MatchingResult(
                schema=schema,
                overall_score=overall,
                subject_match=s_match,
                object_match=o_match,
                action_match=a_match,
                embedding_similarity=emb_sim,
                domain_match=(schema.domain == domain) if domain else True
            ))
            
            if overall > best_score:
                best_score = overall
                best_match = schema
        
        # 决定推荐结果
        recommendation = self._score_to_outcome(best_score)
        
        # 判断是否有效
        # 如果LLM决策与推荐一致，则有效
        # 简化处理：高分允许，低分拒绝
        valid = (
            (best_score >= self.min_alignment_threshold and llm_decision == DecisionOutcome.ALLOW) or
            (best_score < self.limit_threshold and llm_decision == DecisionOutcome.DENY)
        )
        
        # 生成原因
        reason = self._generate_reason(best_score, best_match, recommendation)
        
        end_time = time.perf_counter()
        elapsed_ms = (end_time - start_time) * 1000
        # 性能日志，可开启调试
        # if elapsed_ms > 8:
        #     print(f"Warning: Validation exceeded 8ms target: {elapsed_ms:.2f}ms")
        
        return ValidationResult(
            valid=valid,
            alignment_score=best_score,
            best_match_schema=best_match,
            matching_results=matching_results,
            recommendation=recommendation,
            reason=reason,
            request=request
        )
    
    def _score_to_outcome(self, score: float) -> DecisionOutcome:
        """根据分数映射到五级结果"""
        if score >= self.min_alignment_threshold:
            return DecisionOutcome.ALLOW
        elif score >= self.challenge_threshold:
            return DecisionOutcome.CHALLENGE
        elif score >= self.limit_threshold:
            return DecisionOutcome.LIMIT
        elif score > 0:
            return DecisionOutcome.DENY
        else:
            return DecisionOutcome.ISOLATE
    
    def _generate_reason(self, score: float, best_match: Optional[SecuritySchema], recommendation: DecisionOutcome) -> str:
        """生成推理原因"""
        outcome_names = {
            DecisionOutcome.ALLOW: "允许",
            DecisionOutcome.CHALLENGE: "挑战",
            DecisionOutcome.LIMIT: "限制",
            DecisionOutcome.DENY: "拒绝",
            DecisionOutcome.ISOLATE: "隔离"
        }
        
        if best_match:
            return f"对齐分数 {score:.3f}，最佳匹配基模 '{best_match.name}'，推荐结果: {outcome_names[recommendation]}。{best_match.description}"
        else:
            return f"对齐分数 {score:.3f}，未匹配到任何安全基模，推荐结果: {outcome_names[recommendation]}。"
    
    # ========== 开发2 - 分布式新能源接入管控 ==========
    
    def onboarding_new_terminal(
        self,
        terminal_id: str,
        terminal_type: str
    ) -> float:
        """新终端接入，返回初始信任度"""
        return self.distributed_energy_trust_optimizer.onboarding_terminal(
            terminal_id, terminal_type
        )
    
    def update_terminal_trust(
        self,
        terminal_id: str,
        behavior_valid: bool,
        schema_metadata: dict = None
    ) -> float:
        """更新终端信任度"""
        if schema_metadata is None:
            schema_metadata = {}
        return self.distributed_energy_trust_optimizer.update_trust(
            terminal_id, behavior_valid, schema_metadata
        )
    
    def bulk_update_terminals(
        self,
        updates: list[tuple[str, bool, dict]]
    ) -> int:
        """批量更新终端，支持大规模接入"""
        return self.distributed_energy_trust_optimizer.bulk_update_trust(updates)
    
    # ========== 开发2 - 配电网台区自主管理 ==========
    
    def add_district_node(
        self,
        node_id: str,
        parent_id: Optional[str]
    ) -> None:
        """添加节点到台区分层结构"""
        self.district_hierarchy_manager.add_node(node_id, parent_id)
    
    def check_district_hierarchy_access(
        self,
        requester: str,
        target: str
    ) -> bool:
        """检查分层权限"""
        return self.district_hierarchy_manager.is_access_allowed(requester, target)
    
    def count_district_nodes(self) -> int:
        """获取节点总数，验证规模"""
        return self.district_hierarchy_manager.count_nodes()
    
    # ========== 开发2 - 虚拟电厂协作 ==========
    
    def vpp_add_member(self, vpp_id: str, agent_id: str) -> None:
        """添加成员到虚拟电厂"""
        self.vpp_boundary_manager.add_member(vpp_id, agent_id)
    
    def vpp_remove_member(self, vpp_id: str, agent_id: str) -> None:
        """从虚拟电厂移除成员"""
        self.vpp_boundary_manager.remove_member(vpp_id, agent_id)
    
    def vpp_check_access(
        self,
        requester: str,
        target: str,
        vpp_id: str
    ) -> bool:
        """检查虚拟电厂边界访问"""
        return self.vpp_boundary_manager.check_cross_agent_access(requester, target, vpp_id)
    
    def vpp_get_member_count(self, vpp_id: str) -> int:
        """获取VPP成员数量"""
        return self.vpp_boundary_manager.get_member_count(vpp_id)
    
    # ========== 开发2 - 电网协议兼容 ==========
    
    def map_protocol_function_to_action(
        self,
        protocol: str,
        function_code: str
    ) -> AccessAction:
        """映射电网协议功能码到访问动作"""
        action_str = self.grid_protocol_support.map_function_code_to_action(
            protocol, function_code
        )
        action_map = {
            'read': AccessAction.READ,
            'monitor': AccessAction.MONITOR,
            'write': AccessAction.WRITE,
            'control': AccessAction.CONTROL,
            'configure': AccessAction.CONFIGURE,
        }
        return action_map.get(action_str, AccessAction.READ)
    
    def is_protocol_supported(self, protocol: str) -> bool:
        """检查协议是否支持"""
        return self.grid_protocol_support.is_protocol_supported(protocol)
    
    # ========== 规模统计 ==========
    
    def get_total_node_count(self) -> int:
        """获取总节点数，验证支持10000+"""
        # 台区节点 + VPP成员 + 新能源终端
        district_count = self.district_hierarchy_manager.count_nodes()
        # 终端数量
        terminal_count = len(self.distributed_energy_trust_optimizer._terminal_trust)
        # VPP节点
        vpp_count = sum(
            len(members) for members in self.vpp_boundary_manager._vpp_members.values()
        )
        return district_count + terminal_count + vpp_count
