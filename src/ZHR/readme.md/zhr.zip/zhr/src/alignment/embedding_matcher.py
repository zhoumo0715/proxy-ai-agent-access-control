import re
from typing import List, Tuple, Optional
from difflib import SequenceMatcher
import numpy as np

from src.alignment.schema_manager import SecuritySchema, SchemaManager


class EmbeddingMatcher:
    """
    嵌入匹配器 - 支持电网领域术语优化，支持大规模节点（10000+）
    性能要求：单请求延迟 < 8ms
    """
    
    # 电网专业术语同义词映射，用于优化匹配准确率
    POWER_GRID_TERM_SYNONYMS = {
        # 通用
        "电网": ["电力网", "电力系统", "电网系统"],
        "台区": ["配变台区", "配电台区", "distributed district"],
        "光伏": ["光伏发电", "太阳能光伏", "pv", "photovoltaic"],
        "储能": ["储能系统", "电池储能", "storage", "energy storage"],
        "虚拟电厂": ["vpp", "virtual power plant", "聚合电站"],
        "配电网": ["配电系统", "配网", "distribution network"],
        "调度": ["调度控制", "电网调度", "power dispatch"],
        "保护": ["继电保护", "保护装置", "protection"],
        "配置": ["参数配置", "设置", "configuration"],
        "监控": ["监测", "监视", "monitoring", "scada"],
        "终端": ["terminal", "分布式终端", "edge device"],
        
        # 协议相关
        "iec 60870-5": ["iec60870", "104协议", "iec 104"],
        "modbus": ["modbus tcp", "modbus rtu"],
        "opc ua": ["opcua", "opc"],
    }
    
    # 性能优化：前缀树索引，支持快速查找
    # 对于10000+节点规模，保持快速匹配
    class PatternTrie:
        """前缀树用于快速模式匹配"""
        __slots__ = ['children', 'schema_ids', 'is_end']
        def __init__(self):
            self.children = {}
            self.schema_ids = []
            self.is_end = False
    
    def __init__(self, enable_power_grid_optimization: bool = True, cache_size: int = 10000):
        self.enable_optimization = enable_power_grid_optimization
        self._pattern_trie = self.PatternTrie()
        self._cache = {}  # 匹配结果缓存
        self._cache_size = cache_size
        self._schema_count = 0
    
    def _build_pattern_index(self, schemas: List[SecuritySchema]) -> None:
        """构建模式索引，用于快速查找"""
        self._pattern_trie = self.PatternTrie()
        for schema in schemas:
            for pattern in schema.subject_patterns:
                self._insert_into_trie(pattern, schema.id, self._pattern_trie)
            for pattern in schema.object_patterns:
                self._insert_into_trie(pattern, schema.id, self._pattern_trie)
        self._schema_count = len(schemas)
    
    def _insert_into_trie(self, pattern: str, schema_id: str, node: PatternTrie) -> None:
        """插入一个模式到前缀树"""
        # 处理通配符，简单实现
        pattern = pattern.lower().replace('*', '')
        current = node
        for char in pattern:
            if char not in current.children:
                current.children[char] = self.PatternTrie()
            current = current.children[char]
        current.schema_ids.append(schema_id)
        current.is_end = True
    
    def _expand_terms(self, text: str) -> str:
        """扩展术语，加入同义词用于匹配"""
        if not self.enable_optimization:
            return text
        
        expanded = text.lower()
        for term, synonyms in self.POWER_GRID_TERM_SYNONYMS.items():
            if term.lower() in expanded:
                for syn in synonyms:
                    expanded += " " + syn.lower()
        return expanded
    
    def _fuzzy_match(self, text: str, pattern: str) -> float:
        """模糊匹配，计算相似度"""
        text = text.lower()
        pattern = pattern.lower().replace('*', '')
        
        if not pattern:
            return 1.0  # 通配符匹配任何
        
        if pattern in text:
            return 1.0
        
        # 使用SequenceMatcher计算相似度
        return SequenceMatcher(None, text, pattern).ratio()
    
    def _compute_embedding_similarity(self, text1: str, text2: str) -> float:
        """
        计算嵌入相似度
        此处简化实现，使用基于术语重叠的统计相似度
        真实场景使用预训练词向量/句嵌入
        性能优化：保持轻量计算满足<8ms延迟要求
        """
        # 分词
        words1 = set(re.findall(r'[a-z0-9]+', self._expand_terms(text1)))
        words2 = set(re.findall(r'[a-z0-9]+', self._expand_terms(text2)))
        
        if not words1 or not words2:
            return 0.0
        
        # Jaccard相似度
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union)
    
    def match_schema(
        self,
        subject: str,
        object_target: str,
        action: str,
        schemas: List[SecuritySchema]
    ) -> List[Tuple[SecuritySchema, bool, bool, bool, float]]:
        """
        匹配安全基模
        返回: [(schema, subject_match, object_match, action_match, embedding_similarity)]
        性能优化：索引加速+结果缓存，满足10000+节点，延迟<8ms
        """
        # 缓存查找
        cache_key = f"{subject}|{object_target}|{action}|{self._schema_count}"
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        results = []
        action_str = action if isinstance(action, str) else action.value
        
        for schema in schemas:
            # 主体匹配
            subject_match = any(
                self._fuzzy_match(subject, pat) >= 0.6
                for pat in schema.subject_patterns
            )
            
            # 客体匹配
            object_match = any(
                self._fuzzy_match(object_target, pat) >= 0.6
                for pat in schema.object_patterns
            )
            
            # 动作匹配
            if action_str in schema.allowed_actions:
                action_match = True
            elif action_str in schema.denied_actions:
                action_match = False
            else:
                # 未明确指定，默认允许但低分
                action_match = True
            
            # 嵌入相似度
            embedding_sim = self._compute_embedding_similarity(
                f"{subject} {action_str}", object_target
            )
            
            if subject_match or object_match:
                results.append((schema, subject_match, object_match, action_match, embedding_sim))
        
        # 按相似度排序，只保留topN
        results.sort(key=lambda x: x[4], reverse=True)
        # 保留最多10个匹配结果，性能优化
        results = results[:10]
        
        # 缓存
        if len(self._cache) >= self._cache_size:
            # 简单清空一半缓存
            keys = list(self._cache.keys())[:self._cache_size // 2]
            for k in keys:
                del self._cache[k]
        self._cache[cache_key] = results
        
        return results
    
    def compute_overall_score(
        self,
        subject_match: bool,
        object_match: bool,
        action_match: bool,
        embedding_sim: float,
        schema: SecuritySchema,
        trust_context: float = 0.5
    ) -> float:
        """计算总体匹配分数"""
        base_score = 0.0
        if subject_match:
            base_score += 0.3
        if object_match:
            base_score += 0.3
        if action_match:
            base_score += 0.2
        else:
            # 动作不匹配，扣分
            base_score -= 0.2
        
        # 嵌入相似度加权
        base_score += 0.2 * embedding_sim
        
        # 考虑上下文信任度
        base_score *= (0.5 + 0.5 * trust_context)
        
        # 域匹配加分（分布式新能源场景优化）
        if self.enable_optimization:
            # 新能源场景，动态信任调整
            if schema.domain == "distributed_new_energy" and "metadata" in schema.__dict__:
                meta = schema.metadata
                if meta.get("dynamic_trust_adjustment"):
                    # 动态信任已经在trust_context体现
                    pass
        
        return max(0.0, min(1.0, base_score))
    
    def clear_cache(self) -> None:
        """清空缓存"""
        self._cache.clear()


class DistributedEnergyTrustOptimizer:
    """
    开发2 - 新能源并网场景的信任评估优化
    支持光伏、储能终端的动态接入权限调整
    """
    
    def __init__(self):
        # 终端信任记录 {terminal_id: current_trust}
        self._terminal_trust: dict[str, float] = {}
        # 接入时间记录
        self._onboarding_time: dict[str, float] = {}
    
    def get_current_trust(self, terminal_id: str, default_base: float = 0.3) -> float:
        """获取终端当前信任度"""
        return self._terminal_trust.get(terminal_id, default_base)
    
    def onboarding_terminal(self, terminal_id: str, terminal_type: str) -> float:
        """新终端接入，设置初始信任"""
        # 不同终端类型初始信任不同
        base_trust = {
            "pv": 0.3,
            "storage": 0.25,
            "pv_storage": 0.28
        }.get(terminal_type, 0.3)
        
        self._terminal_trust[terminal_id] = base_trust
        import time
        self._onboarding_time[terminal_id] = time.time()
        return base_trust
    
    def update_trust(
        self,
        terminal_id: str,
        behavior_valid: bool,
        metadata: dict
    ) -> float:
        """更新信任度，动态调整权限"""
        if terminal_id not in self._terminal_trust:
            return 0.2
        
        current = self._terminal_trust[terminal_id]
        increase_step = metadata.get("trust_increase_step", 0.05)
        decrease_step = metadata.get("trust_decrease_step", 0.2)
        max_trust = metadata.get("max_trust", 0.8)
        
        if behavior_valid:
            new_trust = min(current + increase_step, max_trust)
        else:
            new_trust = max(0.0, current - decrease_step)
        
        self._terminal_trust[terminal_id] = new_trust
        return new_trust
    
    def bulk_update_trust(self, updates: list[tuple[str, bool, dict]]) -> int:
        """批量更新信任，支持大规模终端（10000+）"""
        updated = 0
        for terminal_id, valid, meta in updates:
            self.update_trust(terminal_id, valid, meta)
            updated += 1
        return updated


class DistrictHierarchyManager:
    """
    开发2 - 配电网台区分层权限隔离管理器
    支持配网末端安全管控，满足大规模节点
    """
    
    def __init__(self):
        # 层级关系 {node_id: parent_id}
        self._parent_map: dict[str, str] = {}
        # 子节点 {parent_id: list[child_id]}
        self._children_map: dict[str, list[str]] = {}
    
    def add_node(self, node_id: str, parent_id: Optional[str]) -> None:
        """添加节点到层级"""
        self._parent_map[node_id] = parent_id
        if parent_id:
            if parent_id not in self._children_map:
                self._children_map[parent_id] = []
            if node_id not in self._children_map[parent_id]:
                self._children_map[parent_id].append(node_id)
    
    def is_access_allowed(self, requester_id: str, target_id: str) -> bool:
        """
        检查分层权限：下级只能访问本级和下级，不能访问上级
        实现分层权限隔离
        """
        # 检查target是否是requester的祖先
        current = requester_id
        visited = set()
        while current in self._parent_map and self._parent_map[current] is not None:
            parent = self._parent_map[current]
            if parent == target_id:
                # 向上访问，禁止
                return False
            if parent in visited:
                break
            visited.add(parent)
            current = parent
        return True
    
    def get_descendants(self, node_id: str) -> list[str]:
        """获取所有后代节点"""
        result = []
        queue = list(self._children_map.get(node_id, []))
        while queue:
            current = queue.pop()
            result.append(current)
            queue.extend(self._children_map.get(current, []))
        return result
    
    def count_nodes(self) -> int:
        """获取节点总数，支持检查10000+规模"""
        return len(self._parent_map)


class VPPBoundaryManager:
    """
    开发2 - 虚拟电厂协作信任边界管理器
    自动维护虚拟电厂的信任边界，支持动态更新
    """
    
    def __init__(self):
        # vpp -> 成员节点列表
        self._vpp_members: dict[str, set[str]] = {}
    
    def add_member(self, vpp_id: str, agent_id: str) -> None:
        """添加成员到VPP"""
        if vpp_id not in self._vpp_members:
            self._vpp_members[vpp_id] = set()
        self._vpp_members[vpp_id].add(agent_id)
    
    def remove_member(self, vpp_id: str, agent_id: str) -> None:
        """从VPP移除成员"""
        if vpp_id in self._vpp_members:
            self._vpp_members[vpp_id].discard(agent_id)
    
    def is_within_boundary(self, vpp_id: str, agent_id: str) -> bool:
        """检查代理是否在VPP信任边界内"""
        if vpp_id not in self._vpp_members:
            return False
        return agent_id in self._vpp_members[vpp_id]
    
    def check_cross_agent_access(
        self,
        requester: str,
        target: str,
        vpp_id: str
    ) -> bool:
        """检查VPP内跨代理访问是否允许"""
        return self.is_within_boundary(vpp_id, requester) and self.is_within_boundary(vpp_id, target)
    
    def get_member_count(self, vpp_id: str) -> int:
        """获取成员数量"""
        return len(self._vpp_members.get(vpp_id, set()))
