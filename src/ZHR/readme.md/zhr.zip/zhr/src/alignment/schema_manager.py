from typing import List, Dict, Optional
from dataclasses import dataclass, field
import json
import os


@dataclass
class SecuritySchema:
    """安全基模 - 定义访问控制规则"""
    id: str
    name: str
    description: str
    subject_patterns: List[str]  # 主体（请求者）匹配模式
    object_patterns: List[str]  # 客体（目标）匹配模式
    allowed_actions: List[str]  # 允许的动作
    denied_actions: List[str]   # 禁止的动作
    domain: str = "general"     # 所属域: general, district, distributed_new_energy, vpp
    required_threshold: float = 0.0
    metadata: Dict = field(default_factory=dict)
    
    # 电网扩展字段
    voltage_level: Optional[List[str]] = None  # 适用电压等级
    terminal_types: Optional[List[str]] = None  # 适用终端类型
    cross_domain_allowed: bool = False  # 是否允许跨域访问


class SchemaManager:
    """安全基模管理器 - 支持电网多场景扩展"""
    
    def __init__(self):
        self.schemas: Dict[str, SecuritySchema] = {}
        self.domain_index: Dict[str, List[str]] = {}  # 域 -> 基模ID索引
        self.terminal_index: Dict[str, List[str]] = {}  # 终端类型 -> 基模ID索引
    
    def add_schema(self, schema: SecuritySchema) -> None:
        """添加安全基模"""
        self.schemas[schema.id] = schema
        
        # 建立域索引
        if schema.domain not in self.domain_index:
            self.domain_index[schema.domain] = []
        self.domain_index[schema.domain].append(schema.id)
        
        # 建立终端类型索引
        if schema.terminal_types:
            for ttype in schema.terminal_types:
                if ttype not in self.terminal_index:
                    self.terminal_index[ttype] = []
                self.terminal_index[ttype].append(schema.id)
    
    def get_schema(self, schema_id: str) -> Optional[SecuritySchema]:
        return self.schemas.get(schema_id)
    
    def list_schemas(self) -> List[SecuritySchema]:
        return list(self.schemas.values())
    
    def get_schemas_by_domain(self, domain: str) -> List[SecuritySchema]:
        """按域获取基模"""
        if domain not in self.domain_index:
            return []
        return [self.schemas[sid] for sid in self.domain_index[domain] if sid in self.schemas]
    
    def get_schemas_by_terminal(self, terminal_type: str) -> List[SecuritySchema]:
        """按终端类型获取基模（用于分布式新能源接入管控）"""
        if terminal_type not in self.terminal_index:
            return []
        return [self.schemas[sid] for sid in self.terminal_index[terminal_type] if sid in self.schemas]
    
    def load_default_power_grid_schemas(self) -> None:
        """加载电网默认安全基模，包含所有场景"""
        # 1. 基础分区安全规则
        self._add_basic_partition_schemas()
        # 2. 分布式新能源接入管控规则（开发2）
        self._add_distributed_new_energy_schemas()
        # 3. 配电网台区自主管理规则（开发2）
        self._add_district_domain_schemas()
        # 4. 虚拟电厂协作规则（开发2）
        self._add_vpp_collaboration_schemas()
    
    def _add_basic_partition_schemas(self) -> None:
        """基础安全分区规则"""
        # 安全分区 禁止跨区控制
        schema = SecuritySchema(
            id="partition_cross_domain_control_deny",
            name="跨安全分区控制禁止",
            description="根据电力安全规定，禁止不同安全分区之间的跨区控制操作",
            subject_patterns=["*"],
            object_patterns=["*"],
            allowed_actions=["read", "monitor"],
            denied_actions=["control", "configure", "write"],
            domain="general",
            cross_domain_allowed=False,
            required_threshold=0.8
        )
        self.add_schema(schema)
    
    def _add_distributed_new_energy_schemas(self) -> None:
        """
        开发2 - 1. 分布式新能源接入管控
        支持光伏、储能终端的动态接入权限调整，实现新能源并网场景的信任评估优化
        """
        # 光伏终端接入规则
        pv_schema = SecuritySchema(
            id="distributed_pv_terminal_access",
            name="分布式光伏终端接入管控",
            description="台区代理对新接入光伏终端的分级权限控制",
            subject_patterns=["*台区代理*", "district*", "*pv*aggregator*"],
            object_patterns=["*pv*", "*光伏*", "*光伏代理*"],
            allowed_actions=["read", "monitor"],
            denied_actions=[],
            domain="distributed_new_energy",
            terminal_types=["pv"],
            voltage_level=["low"],
            cross_domain_allowed=False,
            required_threshold=0.65,
            metadata={
                "dynamic_trust_adjustment": True,
                "onboarding_trust_base": 0.3,
                "continuous_evaluation": True
            }
        )
        self.add_schema(pv_schema)
        
        # 储能终端接入规则
        storage_schema = SecuritySchema(
            id="distributed_storage_terminal_access",
            name="分布式储能终端接入管控",
            description="储能终端因其可调节特性需要更严格的控制权限管理",
            subject_patterns=["*台区代理*", "*aggregator*", "*vpp*"],
            object_patterns=["*storage*", "*储能*", "*储能代理*"],
            allowed_actions=["read", "monitor", "control"],
            denied_actions=["configure"],
            domain="distributed_new_energy",
            terminal_types=["storage"],
            voltage_level=["low", "medium"],
            cross_domain_allowed=False,
            required_threshold=0.75,
            metadata={
                "dynamic_trust_adjustment": True,
                "onboarding_trust_base": 0.25,
                "continuous_evaluation": True,
                "frequency_evaluation_minutes": 15
            }
        )
        self.add_schema(storage_schema)
        
        # 光储联合接入
        pv_storage_schema = SecuritySchema(
            id="pv_storage_combined_access",
            name="光储联合接入管控",
            description="光储一体化电站的组合权限管控",
            subject_patterns=["*台区代理*", "*pv_storage*", "*aggregator*"],
            object_patterns=["*pv_storage*", "*光储*"],
            allowed_actions=["read", "monitor", "control"],
            denied_actions=["configure"],
            domain="distributed_new_energy",
            terminal_types=["pv_storage"],
            voltage_level=["low", "medium"],
            cross_domain_allowed=False,
            required_threshold=0.7,
            metadata={
                "dynamic_trust_adjustment": True,
                "coordinated_control": True
            }
        )
        self.add_schema(pv_storage_schema)
        
        # 动态信任评估规则
        trust_eval_schema = SecuritySchema(
            id="new_energy_trust_evaluation",
            name="新能源并网信任评估",
            description="新能源接入后持续信任评估，动态调整权限",
            subject_patterns=["*"],
            object_patterns=["*pv*", "*storage*"],
            allowed_actions=["read", "monitor", "control"],
            denied_actions=[],
            domain="distributed_new_energy",
            required_threshold=0.5,
            metadata={
                "trust_optimization": True,
                "trust_increase_step": 0.05,
                "trust_decrease_step": 0.2,
                "max_trust": 0.8,
                "min_trust_for_control": 0.3
            }
        )
        self.add_schema(trust_eval_schema)
    
    def _add_district_domain_schemas(self) -> None:
        """
        开发2 - 2. 配电网台区自主权限管理
        实现台区代理的分层权限隔离，支持配网末端安全管控
        """
        # 台区分层权限隔离
        district_isolation = SecuritySchema(
            id="district_hierarchical_isolation",
            name="配电网台区分层权限隔离",
            description="台区内分层权限隔离，下级只能访问本级及以下资源",
            subject_patterns=["*台区*", "*district*", "*feeder*"],
            object_patterns=["*terminal*", "*load*", "*pv*", "*storage*"],
            allowed_actions=["read", "monitor", "control"],
            denied_actions=["configure"],
            domain="district",
            cross_domain_allowed=False,
            required_threshold=0.7,
            metadata={
                "hierarchical_depth": 4,
                "upward_access_deny": True,
                "cross_feeder_isolation": True
            }
        )
        self.add_schema(district_isolation)
        
        # 配网末端终端管控
        district_terminal_control = SecuritySchema(
            id="district_terminal_control",
            name="配电网末端终端安全管控",
            description="配网末端大量分布式终端的自主管控",
            subject_patterns=["*台区代理*"],
            object_patterns=["*terminal*"],
            allowed_actions=["read", "monitor", "write"],
            denied_actions=["control", "configure"],
            domain="district",
            cross_domain_allowed=False,
            required_threshold=0.6,
            metadata={
                "bulk_terminal_support": True,
                "batch_permission_update": True
            }
        )
        self.add_schema(district_terminal_control)
    
    def _add_vpp_collaboration_schemas(self) -> None:
        """
        开发2 - 3. 虚拟电厂协作访问控制
        实现跨主体代理节点的动态协作权限，自动维护虚拟电厂的信任边界
        """
        # 虚拟电厂跨主体协作
        vpp_collab = SecuritySchema(
            id="vpp_cross_agent_collaboration",
            name="虚拟电厂跨主体协作权限",
            description="虚拟电厂内多主体代理协作访问控制",
            subject_patterns=["*vpp*", "*virtual_power_plant*", "*aggregator*"],
            object_patterns=["*pv*", "*storage*", "*load*", "*district*"],
            allowed_actions=["read", "monitor", "control"],
            denied_actions=["configure"],
            domain="vpp",
            cross_domain_allowed=True,
            required_threshold=0.65,
            metadata={
                "dynamic_boundary_maintenance": True,
                "member_trust_sharing": True,
                "auto_boundary_update": True
            }
        )
        self.add_schema(vpp_collab)
        
        # 虚拟电厂外部访问禁止
        vpp_isolation = SecuritySchema(
            id="vpp_external_access_isolation",
            name="虚拟电厂信任边界隔离",
            description="禁止虚拟电厂信任边界外的未授权访问",
            subject_patterns=["*"],
            object_patterns=["*vpp*internal*"],
            allowed_actions=[],
            denied_actions=["read", "monitor", "write", "control", "configure"],
            domain="vpp",
            cross_domain_allowed=False,
            required_threshold=0.8
        )
        self.add_schema(vpp_isolation)


class GridProtocolSupport:
    """
    开发2 - 4. 电网协议兼容
    支持IEC 60870-5、Modbus、OPC UA等工业协议的访问控制映射
    """
    
    # 协议功能码 -> 访问动作映射
    PROTOCOL_ACTION_MAPPING = {
        # IEC 60870-5-104 协议
        "iec60870_5_104": {
            "read": ["M_SP_NA_1", "M_ME_NA_1", "M_ME_NC_1", "M_IT_NA_1"],
            "monitor": ["C_SC_NA_1", "C_CC_NA_1"],
            "write": ["C_SE_NA_1", "C_SE_NB_1", "C_SE_NC_1"],
            "control": ["C_CS_NA_1", "C_TS_TA_1"],
            "configure": ["C_RP_NA_1", "C_IG_NA_1"]
        },
        # Modbus TCP
        "modbus": {
            "read": ["read_coils", "read_discrete_inputs", "read_holding_registers", "read_input_registers"],
            "monitor": ["read_holding_registers"],
            "write": ["write_single_coil", "write_single_register", "write_multiple_coils", "write_multiple_registers"],
            "control": ["write_multiple_coils", "write_multiple_registers"],
            "configure": ["write_multiple_registers"]
        },
        # OPC UA
        "opc_ua": {
            "read": ["read"],
            "monitor": ["subscribe", "read"],
            "write": ["write"],
            "control": ["call", "write"],
            "configure": ["add_node", "delete_node", "write_attributes"]
        }
    }
    
    @classmethod
    def map_function_code_to_action(cls, protocol: str, function_code: str) -> str:
        """将协议功能码映射到访问动作"""
        protocol = protocol.lower().replace('-', '_')
        if protocol in cls.PROTOCOL_ACTION_MAPPING:
            for action, fcs in cls.PROTOCOL_ACTION_MAPPING[protocol].items():
                if function_code in fcs:
                    return action
        return "read"  # 默认
    
    @classmethod
    def is_protocol_supported(cls, protocol: str) -> bool:
        """检查协议是否支持"""
        return protocol.lower().replace('-', '_') in cls.PROTOCOL_ACTION_MAPPING
