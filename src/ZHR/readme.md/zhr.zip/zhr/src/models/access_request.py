from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import uuid
from typing import Dict, Optional, Any


class AccessAction(Enum):
    """访问动作枚举"""
    READ = "read"         # 读取数据
    MONITOR = "monitor"   # 监控数据
    WRITE = "write"       # 写入数据
    CONTROL = "control"   # 控制操作
    CONFIGURE = "configure"  # 配置修改


class DecisionOutcome(Enum):
    """决策结果枚举 - 五级响应机制"""
    ALLOW = "allow"       # 允许 (≥0.8)
    CHALLENGE = "challenge"  # 挑战 (≥0.5)
    LIMIT = "limit"       # 限制 (≥0.2)
    DENY = "deny"         # 拒绝 (>0)
    ISOLATE = "isolate"   # 隔离 (≤0)


@dataclass
class AccessRequest:
    """访问请求模型"""
    request_id: str
    requester_id: str          # 请求者代理ID
    target_id: str             # 目标资源/代理ID
    action: AccessAction       # 请求动作
    context: Dict[str, Any] = field(default_factory=dict)  # 上下文信息
    timestamp: datetime = field(default_factory=datetime.now)
    
    # 电网扩展字段
    domain: Optional[str] = None  # 域: district(台区), distributed_new_energy(分布式新能源), vpp(虚拟电厂)
    terminal_type: Optional[str] = None  # 终端类型: pv(光伏), storage(储能), pv_storage(光储)
    grid_voltage_level: Optional[str] = None  # 电压等级: low, medium, high
    
    def to_dict(self):
        return {
            "request_id": self.request_id,
            "requester_id": self.requester_id,
            "target_id": self.target_id,
            "action": self.action.value,
            "context": self.context,
            "timestamp": self.timestamp.isoformat(),
            "domain": self.domain,
            "terminal_type": self.terminal_type,
            "grid_voltage_level": self.grid_voltage_level
        }


@dataclass
class MatchingResult:
    """匹配结果"""
    schema: 'SecuritySchema'
    overall_score: float
    subject_match: bool
    object_match: bool
    action_match: bool
    embedding_similarity: float
    domain_match: bool = True


@dataclass
class ValidationResult:
    """验证结果"""
    valid: bool
    alignment_score: float
    best_match_schema: Optional['SecuritySchema']
    matching_results: list[MatchingResult]
    recommendation: DecisionOutcome
    reason: str
    request: AccessRequest
